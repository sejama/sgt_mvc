---
title: 6 square
categories:
  - Shapes
tags:
  - number
  - numeral
---
